package com.jobvista.service;

public interface AddressService {

}
