package com.jobvista.exception;

public class ApiCustomException extends RuntimeException{
	public ApiCustomException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
}
