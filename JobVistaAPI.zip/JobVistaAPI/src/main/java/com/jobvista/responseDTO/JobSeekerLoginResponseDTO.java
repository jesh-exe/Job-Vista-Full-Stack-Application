package com.jobvista.responseDTO;

public class JobSeekerLoginResponseDTO {
	
	

}
