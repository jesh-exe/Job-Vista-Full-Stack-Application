package com.jobvista.requestDTO.jobSeekerDTO;

import lombok.Data;

@Data
public class JobSeekerCredsRequestDTO {
<<<<<<< HEAD

	String email;
	String password;

=======
	String email;
	String password;
>>>>>>> 0c7acf78bd7bc2b9b2c9362056f8e24564635438
}
